
/* ======== Macros ======== */

/* Constants */
#define MAX_DATA_NUM				1000
#define MAX_LINES_NUM				700
#define FIRST_ADDRESS				100 
#define MAX_LINE_LENGTH				80
#define MAX_FILE_NAME_LENGTH		        50
#define MAX_LABEL_LENGTH			30
#define MEMORY_WORD_LENGTH			15	
#define MAX_REGISTER_DIGIT			7
#define MAX_CHAR_IN_SPEC_BASIS			5 /* It's enougth to hold the biggest decimal number 2 power 14. */
#define MAX_FILES_CREATED  		        3
#define FALSE					0
#define TRUE					1

#define FOREVER					for(;;)

/* =========== Data Structures ============ */

typedef unsigned int bool; /* Only get TRUE or FALSE values */

/* ======= First Read  ===== */

 /* Labels Management */

typedef struct node *ptr;

typedef struct node {
	char name[MAX_LABEL_LENGTH];				/* The name of the label. */
	int lineNumber;						/* The line number. */
	int address;						/* The address it contains. */
	int flagExtern;						/* Holds true if this is a extern. */
	int flagOper;						/* Holds true if there is a operation after label. */
	ptr nextLabel;						/* Pointer to the next label. */
	ptr prevLabel;						/* Pointer to the previos label. */
} label;

/*========== Directive ===========*/

typedef struct
{	 
	bool isErr;/* This boolean will creat an array of boolean that
				sereve us as a indicator if there is an error at 
				the line number that equals to the place in the array. */	
	int lineNmbr;
	char *str;
} error;

/*========= Commands =========*/

typedef struct
{
	int opcode;
	char *name;
	int numOfParams;
} command;


/* === Second Read  === */

/* Memory Word */

typedef struct { /* 15 bits */

	union {	/* commad or register or other separation of the 15 bits*/

			/* Registers */
		struct {
			unsigned int e_r_a : 2;		/* External || Relocatable || Absolute */
			unsigned int dest : 6;		/* Destination register */
			unsigned int src : 6;		/* Source register */
			unsigned int z : 1;			/* Unused Bit */
		} regBits;

		/* Commands */
		struct {
			unsigned int e_r_a : 2;		/* External || Relocatable || Absolute */
			unsigned int dest : 2;		/* Destination operator */
			unsigned int src : 2;		/* Source operator */
			unsigned int opcode : 4;	/* Function Field */
			unsigned int group : 2;		/* Number of parameters */
			unsigned int extra : 3;		/* Not in use */
		} cmdBits;

		/* Other operands */
		struct {
			unsigned int e_r_a : 2;		/* External || Relocatable || Absolute */
			unsigned int dest : 13;		/* Destination operator */
		} otherBits;

		struct {
			unsigned int all : 15;		/* All 15 bits */
		} allBits;


	} bitim;	/* Bitim will hold diffrent types of structhers of 15 bits */

} encodingWord;


/* Operand Management */

typedef struct nodeOp *oPtr;

typedef struct nodeOp {
	char name[MAX_LABEL_LENGTH];			/* The name of the label. */
	int minIndexBit;						/* The first number of the range. */
	int maxIndexBit;						/* The second number of the range. */
	unsigned int rslt : 13;					/* The first number of the range. */
	int lineNmbr;							/* The line number of the operand. */
	int indexIC;							/* The address for the operand. */
	bool isDinam;							/* Holds true if this is a dinmic. */
	oPtr nextOpLbl;			/* Pointer to the next Dinamaic */
	oPtr prevOpLbl;			/* Pointer to the previos Dinamaic */
}operand;

