/*
This file is the first read of an assembly file.
It's detect errors, And if was no errors it's save data to the next reading.

=======================
Author: Hagay Enoch
ID:     203089917
=======================
*/

#include "firstReadFile.h"


enum MyEnum { nmbr = 0, lbl = 1, dinmi = 2, reg = 3 };

/* ====== Methods ====== */


/* ==================================== PART 2 ============================================== */

/* Puts the number in the string 'str' in value.
Returns true if the string 'str' is a number, and it can start with '+' or '-'. */
bool isInteger(char *str, int *value)
{
	int num = 1;

	if (*str == '+')
		str++;
	if (*str == '-')
	{
		num = -1;
		str++;
	}

	if (strlen(str) == 0)
		return FALSE;

	*value = atoi(str)*num; /* Put the number into 'value'. */

	while (str && strlen(str))
	{
		if (!isdigit(*str))
			return FALSE;
		str++;
	}
	return TRUE;
}

/* isLegalEncod: return true if the addressing methods of the operand are legal. */
/* 'srcOrDest' is holdind "src" if the operand is source and "dest" otherwise. */
/* 'encodMeth' is holds the addressing method code. */
bool isLegalEncod(char *srcOrDest, int encodMeth)
{
	int opcode = lines[IC].bitim.cmdBits.opcode;
	int howManyParm = getCmdNumParm(opcode);
	char *str[] = { "first" , "second" };

	if (opcode == 1) /* Command is 'cmp'. */
		return TRUE;

	if (opcode == 14 || opcode == 15) /* Command is 'rts' or 'stop'. */
		return FALSE;

	if (strcmp(srcOrDest, "src") == 0) /* Check if source operand. */
	{
		if (opcode < 4) /* Command is 'mov', 'cmp', 'add' or 'sub'. */
			return TRUE;
		else if (encodMeth == 1 && opcode == 6) /* Command is 'lea'. */
			return TRUE;
		else
		{
			storeErr("Command '%s' not support %s operand addressing method.", getNameOfCmd(opcode), str[0]);
			return FALSE;
		}
	}
	else /* Destination operand. */
	{
		if (encodMeth == 1 || encodMeth == 3) /* Addressing method is direct addressing or register direct addressing.*/
			return TRUE;

		else if (opcode != 12)
		{
			storeErr("Command '%s' not support %s operand addressing method.", getNameOfCmd(opcode), str[1]);
			return FALSE;
		}
		return TRUE; /* Command is 'prn'. */
	}
}


/* encodeInteger: encoding integer operand. */
void encodeInteger(bool isSrcBits, int val, int encodMeth)
{
	/* 'howManyParm' gets how many parameters needs to the command. */
	int tmp = 0, howManyParm = getCmdNumParm(lines[IC].bitim.cmdBits.opcode);


	if (howManyParm == 1) /* There is one operand. */
	{
		if (isLegalEncod("dest", encodMeth))
			lines[IC + 1].bitim.otherBits.dest = val;
		IC = IC + 2;
	}
	else if (isSrcBits) /* There is two operands and we read the 1st one. */
	{
		if (isLegalEncod("src", encodMeth))
			lines[IC + 1].bitim.otherBits.dest = val;
	}
	else  /* There is two operands and we read the 2nd */
	{
		if (isLegalEncod("dest", encodMeth))
			lines[IC + 2].bitim.otherBits.dest = val;
		IC = IC + 3;
	}
}

/* encodeReg: encoding register operand. */
void encodeReg(bool isSrcBits, int val, bool opOneReg, int encodMeth)
{
	/* 'howManyParm' gets how many parameters needs to the command. */
	int howManyParm = getCmdNumParm(lines[IC].bitim.cmdBits.opcode);

	/* Initialized src bits and dest bits. */

	if (howManyParm == 1)/* There is one operand. */
	{
		lines[IC].bitim.cmdBits.dest = reg;
		if (isLegalEncod("dest", encodMeth))
			lines[IC + 1].bitim.regBits.dest = val;
		IC = IC + 2;
	}
	else if (isSrcBits)/* There is two operands and we read the 1st or there is one operand. */
	{
		lines[IC].bitim.cmdBits.src = reg;
		if (isLegalEncod("src", encodMeth))
			lines[IC + 1].bitim.regBits.src = val;
	}

	/* There is two operands. */
	else if (opOneReg) /* Reading the 2nd operand while the 1st operand was a register*/
	{
		lines[IC].bitim.cmdBits.dest = reg;
		if (isLegalEncod("dest", encodMeth))
			lines[IC + 1].bitim.regBits.dest = val;
		IC = IC + 2;
	}
	else /* Reading the 2nd operand while the 1st operand wasn't a register*/
	{
		lines[IC].bitim.cmdBits.dest = reg;
		if (isLegalEncod("dest", encodMeth))
			lines[IC + 2].bitim.regBits.dest = val;
		IC = IC + 3;
	}
}

/* encodeDinamicOrLabel: add one operand to the operand list.
And finish encoding the src bits and dest bits.
- 'label' is name of operand.
- 'isSrcBits' is true if the operand is a source operand.
- 'first' holds the litel limit of the range of a dinamc.
- 'second' holds the high limit of the range of a dinamc.
- 'encodeMeth' holds 1 for sempale label and 2 for dinamic label.
- 'isDinam' true if it's dinamic label.   */
void encodeDinamicOrLabel(char* labl, bool isSrcBits, int first, int second, int encodMeth, bool isDinam)
{
	/* 'howManyParm' gets how many parameters needs to the command. */
	int howManyParm = getCmdNumParm(lines[IC].bitim.cmdBits.opcode);

	/* Creat a node of operand. */
	oPtr opLbl = (oPtr)malloc(sizeof(operand));
	if (opLbl == NULL)
	{
		printf("error: Malloc failed.");
		exit(1);
	}

	/* Initialized all arguments of operand. */
	strcpy(opLbl->name, labl);
	opLbl->isDinam = isDinam;
	opLbl->lineNmbr = lineNum;
	bool isLegal = TRUE;

	opLbl->minIndexBit = first;
	opLbl->maxIndexBit = second;

	/* Initialized src bits and dest bits. */

	if (howManyParm == 1) /* There is one operand. */
	{
		lines[IC].bitim.cmdBits.dest = encodMeth;
		isLegal = isLegalEncod("dest", encodMeth);
		opLbl->indexIC = IC + 1;
		IC = IC + 2;
	}
	else if (isSrcBits)/* There is two operands and we read the 1st operand. */
	{
		lines[IC].bitim.cmdBits.src = encodMeth;
		isLegal = isLegalEncod("src", encodMeth);
		opLbl->indexIC = IC + 1;
	}
	else  /* There is two operands and we read the 2nd */
	{
		lines[IC].bitim.cmdBits.dest = encodMeth;
		isLegal = isLegalEncod("dest", encodMeth);
		opLbl->indexIC = IC + 2;
		IC = IC + 3;
	}

	if (isLegal)
	{
		/* Adds a operand to the operand list. */
		addOpLbl(opLbl);
	}
}

/* isLegalOper: analysis operand, And if the operand is legal
encode the the operand in the appropriate address.
- 'isSrcBits' is true if we read the first operand from
a two parameters command. And false otherwise.
- 'FirstOpIsReg' is true if we read the second operand from
a two parameters command. And the first one was a rgister.
And false otherwise. */
bool isLegalOper(char* op, bool isSrcBits, bool *FirstOpIsReg)
{
	bool isOp = FALSE; /* 'isOp' is a flag that true if the operand is legal. */
	char labelName[MAX_LINE_LENGTH];
	strcpy(labelName, op);
	int val, numOne = 0, numTwo = 0;

	if (*op == '#' && isInteger(op + 1, &val))/* Check if the operand is integer. */
	{
		encodeInteger(isSrcBits, val, 0);
		isOp = TRUE;
	}

	/* Check if the operand is dinamic, if so store the
	limits of range in 'numOne' and 'numTwo'. */
	else if (isDinamic(op, &numOne, &numTwo))
	{
		encodeDinamicOrLabel(op, isSrcBits, numOne, numTwo, dinmi, TRUE);
		isOp = TRUE;
	}

	/* Checks if the operand is register, if so store the number of register in 'val'. */
	else if (isRegister(op, &val))
	{
		encodeReg(isSrcBits, val, *FirstOpIsReg, 3);

		if (isSrcBits)
			*FirstOpIsReg = TRUE; /* Save flag that the first operand is a register. */
		isOp = TRUE;
	}
	else
	{
		/* Change temporary the flag of error in current line for
		that the method "sortErr" - not pritning any errors. */
		bool tmpi = errList[lineNum].isErr; /* Save real state in 'tmpi'. */
		errList[lineNum].isErr = TRUE; /* Makes flag- true for error in current line. */

		if (isLegalLabel(op)) /* Check if the operand is label. */
		{
			encodeDinamicOrLabel(labelName, isSrcBits, 0, 0, lbl, FALSE);
			isOp = TRUE;
		}

		/* Returns the real state of the error in current line. */
		errList[lineNum].isErr = tmpi;
	}

	if (!isOp) /* The operand is illegal. */
		storeErr("Operand '%s' is illegal.", op);
	return isOp;
}

/* readsOneOperand: Checks one operand if is legal*/
void readsOneOperand(char *opOne)
{
	bool tmp = FALSE;/* unused boolean for the method 'isLegalOper'. */
	bool isSrcBits = FALSE;

	/* Initialized group bits with "1" for 1 operand. */
	lines[IC].bitim.cmdBits.group = 1;

	/* Check the operand if legal. */
	isLegalOper(opOne, isSrcBits, &tmp);
}

/* readsTwoOperands:  Checks Two operands if is legals. */
void readsTwoOperands(char *opOne, char *opTwo)
{
	bool isReg1 = FALSE;
	bool isSrcBits = TRUE;

	/* Initialized group bits with "2" for 2 operand. */
	lines[IC].bitim.cmdBits.group = 2;

	/* Check the first operand if legal. */
	if (!isLegalOper(opOne, isSrcBits, &isReg1))
		return;

	isSrcBits = FALSE;

	/* Check the second operand if legal. */
	isLegalOper(opTwo, isSrcBits, &isReg1);
}


/* howManyOperFound: Analysing the string sends to her,
And puts the first operand in 'op1'.
And puts the second operand in 'op2'.
Return how many oper found.*/
int howManyOperFound(char **opOne, char **opTwo, char *str)
{
	/* 'firstOp' holds the first part until the first comma in 'str'. */
	char *firstOp = strtok(str, ",");

	if (firstOp) /* Checks if there is no operands.*/
	{
		trimStr(&firstOp);

		/* Checks again if there was just white spaces. */
		if (firstOp)
		{
			/* Found a word after the command name.*/

			*opOne = firstOp; /* Store the first word after the command name in opOne. */

							  /* 'secOp' holds the seconed part until the end of 'str'. */
			char *secOp = strtok(NULL, "\0");

			/* Checks if there is no second operand.*/
			if (secOp)
			{
				trimStr(&secOp);

				/* Checks again if there was just white spaces. */
				if (secOp)
				{
					/* Found a word after first comma in 'str' . */

					*opTwo = secOp;/* Store the rest of 'str' after first comma in opTwo. */
					return 2;
				}
			}
		}
		else
			return 0;
	}

	/* Its must be one operand. */
	return 1;
}

/* isValidOperetion: Checks if the string 'str' is a legal command. */
void isValidOperetion(char* str)
{
	int numOfParm = 0;
	int opcode = 0;
	char *op1 = "";
	char *op2 = "";
	int val = 0;

	/* 'funcName' holds the first word in the line. */
	char *funcName = strtok(str, " \t");

	trimStr(&funcName);

	/* Checks if the first word is a legal command name. */
	if ((isFuncName(funcName, &opcode)))
	{
		/* The first word is a legal command name. */

		/* 'rest' holds the rest of the line. */
		char *rest = strtok(NULL, "\0");

		/* Initialized opcode and extra bits and*/
		lines[IC].bitim.cmdBits.opcode = opcode;
		lines[IC].bitim.cmdBits.extra = 5;

		/* Checks if rest is not NULL. */
		if (rest)
		{
			/* 'numOfParm': gets the actual number of parameters. */
			/* op1 holding the string represent the first operand. */
			/* op2 holding the string represent the second operand. */
			numOfParm = howManyOperFound(&op1, &op2, rest);
		}
		else if (opcode < 14) /* Checks if the command name is 'rst or 'stop' commands. */
		{
			/* There is zero parameters and it's not 'rst or 'stop' commands. */
			storeErr("There is no operands.");
			return;
		}

		/* Compare the actual parm number and the legal parm number. */
		if (cmdArr[opcode].numOfParams != numOfParm)
		{
			int num = cmdArr[opcode].numOfParams;
			char *name = cmdArr[opcode].name;
			storeErr("Number of parm to cmd '%s' is illgal, needs to be %d parm.", name, num);
		}

		else /* This is a legal command with a suitable number of parameters. */
		{
			if (numOfParm == 0) /* The operation is 'stop' or 'rst'. */
				IC++;
			else if (numOfParm == 1)
				readsOneOperand(op1); /* Checks the legalization of one parameter. */
			else
				readsTwoOperands(op1, op2);/* Checks the legalization of two parameters. */
		}
	}
	else if (isDirect(funcName, &val))
		storeErr("'%s' directive must have a dot connected to before.", funcName);
	else
		storeErr("'%s' is not a legal command name.", funcName);
}


/* ==================================== PART 1 ============================================== */


/* Return true if there is enough memory. */
bool thereIsEnoughMem()
{
	/* Check if there is enough space in dataMem for the data */
	if (DC + IC < MAX_DATA_NUM)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}


/* Adds the str to the g_dataArr and increases DC. Returns if it succeeded. */
void addStringToMem(char *str)
{
	if (!isLegalStringParam(&str))
		return;

	while (*str)
	{
		if (thereIsEnoughMem())
		{
			dataMem[DC] = (int)(*str);/* Insert the ascii code of the charatcter into the data array. */
			(*str++);
			DC++;
		}
		else
		{
			storeErr("Not enough memory.");
			return;
		}
	}

	if (thereIsEnoughMem())
	{
		dataMem[DC] = 0;
		DC++;
	}
	else
	{
		storeErr("Not enough memory.");
		return;
	}
	return;
}

/* Store one integer in to the data memory. */
void addOneNumToMem(int tmp)
{
	if (thereIsEnoughMem())
		dataMem[DC] = tmp;
	DC++;
	return;
}

/* Store an array of integers in the data array. */
void addNumbersToMem( char *str)
{
	char *h;
	int tmp;
	int flagMin;

	while (str && *str != '\n' && *str != '\0')
	{
		flagMin = 1;

		trimStr(&str);/* Skip white space before the number. */
		
		if (*str == '-')
		{
			flagMin = -1;
			str++;
		}

		if (*str == '+')
		{
			str++;
		}

		tmp = (int)strtol(str, &h,10);/*tmp holds the number, str is a string with just the number, h is the rest of the string */

		trimStr(&h);

		if (!isdigit(*str) || *str == ',' || (*h != ',' && *h != '\0' && *h != '\n')) 
		{
			/*if p point to a comma- the user enter couple of comma's in a row and if h point to somthing else then ',' and '\0' the user enter a non digit input*/
			
			storeErr("Worng parameters, parameter must be a real number.");
			return;
		}
		else {
			if (*h == ',')
				h++;/* h points to the rest of the string with out the first comma */
			str = strtok(h, "\0");/* p points to the rest of the string*/


			if (thereIsEnoughMem())
				addOneNumToMem(tmp*flagMin);
			else
			{
				storeErr("Not enough memory.");
				return;
			}
		}
	}
}


/* Creats a label and store the label in the label list. */
void createLabelAndInsert(char* name, bool isExtren, bool isOperation)
{
	ptr  p = (ptr)malloc(sizeof(label));

	if (p == NULL) 
	{
		printf("error: Malloc failed.");
		exit(1);
	}

	strcpy(p->name, name);
	p->lineNumber = lineNum;
	if(isOperation)
		p->address = FIRST_ADDRESS + IC;
	else if(isExtren)
		p->address = 0;
	else
		p->address = DC;
	p->flagExtern = isExtren;
	p->flagOper = isOperation;

	addLabel(p);
	return;
}


/* Puts a line from 'file' in 'str'. Returns TRUE if the line's length is at the most 'MAX_LINE_LENGTH' . */
bool readLine(FILE *file, char *str)
{
	char *end;

	if (!fgets(str, MAX_LINE_LENGTH +2 , file))
	{
		return FALSE;
	}

	/* Check if the line is too long (no '\n' was present). */
	end = strchr(str, '\n');
	if (end)
	{
		*end = '\0';
	}
	else
	{
		char c;
		bool ret = (feof(file)) ? TRUE : FALSE; /* Return FALSE, unless it's the end of the file */
								
		do 	/* Keep reading chars until you reach the end of the line ('\n') or EOF */
		{
			c = fgetc(file);
		} while (c != '\n' && c != EOF);

		return ret;
	}

	return TRUE;
}


/* Reading the file for the first time, line by line, and encode it. */
void firstFileRead(FILE *file)
{
	char string[MAX_LINE_LENGTH + 2];
	char saveLine[MAX_LINE_LENGTH + 3];
	int direct = 0;
	int flag = 0;
	char *restOfLine;
	bool withDot = TRUE;

	/* First Read Algoritm */
	/* Read lines and encode them */	
	while (!feof(file))
	{
		lineNum++;
		if (readLine(file, string))						
		{
			direct = 0;
			flag = 0;

			/* Check if the file is too long */
			if (lineNum >= MAX_LINES_NUM)
			{
				storeErr("File is too long. Max lines number in file is %d.", MAX_LINES_NUM);
				return;
			}

			if (isCommentOrEmpty(string))
				continue;

			/* Check if there is a label in the start of the line.
				store the label in 'string', and the rest of the line to 'restOfLine'. */
			if (restOfLine = thereIsValidLabel(string))
				flag = 1; /* Turn on flag- to remember that there was a label. */																	/* ALG4 */
			else
				restOfLine = string; /* Store the line in 'restOfLine'.*/

			if (restOfLine)
			{
				trimStr(&restOfLine);
				strcpy(saveLine, restOfLine); /* copy the string without label. */
			}


			/* Check existence of directives. 
				if was found:
				- 'string' is 
				- 'restOfLine' hold the rest of line after directive.
				- direct gets 1,2,3,4 represent string,data,entry,extern respectively. */
			if (thereIsADirect(&restOfLine, &direct))
			{
				switch (direct)
				{
				case 1:	if (flag)	/* String */
					createLabelAndInsert(string, FALSE, FALSE);
					addStringToMem(restOfLine);
					continue; break;

				case 2: /* Data */
					if (flag)
						createLabelAndInsert(string, FALSE, FALSE);
					addNumbersToMem(restOfLine);
					continue; break;

				case 3: if (flag) /* Entry */
				{
					storeErr("Symbol can't be with directive \"entry\".");
				}continue; break;

				case 4:	if (flag) /* Extern */
				{ 
					storeErr("Symbol can't be with directive \"extern\".");
					continue;
				}

						else if (isLegalLabel(restOfLine))					
							createLabelAndInsert(restOfLine, TRUE, FALSE);
					continue; break;

				default:break;
				}
			}
			else
				restOfLine = saveLine;/* canceling changes of method "isDirect". */
			
			/* There was no directive. */
			if (flag)
			{
				/* There was a label with no directive then it must be an operation. */
				createLabelAndInsert(string, FALSE, TRUE); 
				if (isWhiteSpaces(restOfLine))
				{
					storeErr("Symbol have to be with command or directive.");
					continue;
				}
			}
			/* Checks if the line is a legal command and encod the command. */
			isValidOperetion(restOfLine);					
		}
	}
	return;
}

