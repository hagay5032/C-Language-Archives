
/* ======= Includes ======= */

#include "dataStructhers.h"
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

/* ======= Global Data Structhers & Global Variables ======= */


extern int dataMem[MAX_DATA_NUM];
extern int IC;
extern int DC;
extern int lineNum;
extern command cmdArr[];
extern encodingWord lines[MAX_LINES_NUM];
extern error errList[MAX_LINES_NUM];

/* ======= Method ======= */

/* Declared in file " useful.c ". */
bool isLegalStringParam(char **strParam);
bool isCommentOrEmpty(char *line);
bool isWhiteSpaces(char *str);
bool thereIsADirect(char** line, int* value);
void trimStr(char **ptStr);
bool isLegalLabel(char *label);
char *thereIsValidLabel(char *line);

/* from file " sortError.c ". */
void storeErr(const char *lastArg, ...);

