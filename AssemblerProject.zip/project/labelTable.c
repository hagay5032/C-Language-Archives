/* This file manages the two data linked lists of - labels and operand labels.
	- Also this file creates the extern file(if needed) with the method 'fillHoles'.
*/ 

#include "labelTable.h"


/* ===========================  OPERANDS LABEL LIST ========================== */

/* Returns true if the label exists. */
ptr isExistingLabel(char *labelName)
{
	int i = 0;

	if (labelName)
	{
		ptr p = labelHead;
		for (i = 0; i < labelNum; p = p->nextLabel, i++)
			if (strcmp(labelName, p->name) == 0)
				return p;
	}
	return NULL;
}


/* adjustAddresses: Giving all the data memory line a fitting address.*/
void adjustAddresses()
{
	int i = 0;
	ptr p = labelHead;
	for (i = 0; i < labelNum; p = p->nextLabel, i++)
	{
		if (p->flagExtern == FALSE && p->flagOper == FALSE)
			p->address += FIRST_ADDRESS + IC;
	}
}


/* existsEntry: Return true if this is the first time of decleration of this entry. */
bool existsEntry(char *labelName)
{
	int i = 0;

	if (labelName)
	{
		oPtr p = opHead;
		for (i = 0; i < opNum; p = p->nextOpLbl, i++)
			if (strcmp(labelName, p->name) == 0)
				return TRUE;
	}
	return FALSE;
}


/* Adds label to the label list and increases 'labelNum'. */
void addLabel(ptr newLabel)
{

	if (labelNum == 0) /* The list is empty. */
	{
		labelHead = newLabel;
		newLabel->prevLabel = labelHead;
		newLabel->nextLabel = labelHead;
	}
	else if (labelNum == 1)/* The list has one label. */
	{
		newLabel->prevLabel = labelHead;
		newLabel->nextLabel = labelHead;
		labelHead->prevLabel = newLabel;
		labelHead->nextLabel = newLabel;
	}
	else /* The list has mare then one label. */
	{
		newLabel->prevLabel = labelHead->prevLabel;
		newLabel->nextLabel = labelHead;
		labelHead->prevLabel->nextLabel = newLabel;
		labelHead->prevLabel = newLabel;
	}
	labelNum++;
	return;
}


/* Free the list of labels. */
void freeLabelList()
{
	ptr p;

	while (labelNum)
	{
		/* 'p' is temporary pointer to the head of the list. */
		p = labelHead;

		if (labelNum == 1)
			free(p);
		else
		{
			/* The 'next' pointer of the last label become pointing to the second label. */
			labelHead->prevLabel->nextLabel = labelHead->nextLabel;

			/* The 'prev' pointer of the second label become pointing to the last label. */
			labelHead->nextLabel->prevLabel = labelHead->prevLabel;

			/* The head of the list become pointing to the second label. */
			labelHead = labelHead->nextLabel;

			/* Free the label node that the head of the list was poiting to. */
			free(p);
		}
		labelNum--;
	}
}



/* ===========================  OPERANDS LABEL LIST ========================== */


/* addOpLbl: Adds a operand to the operand list. */
void addOpLbl(oPtr newOp)
{
	if (opNum == 0)
	{
		opHead = newOp;
		newOp->prevOpLbl = opHead;
		newOp->nextOpLbl = opHead;
	}
	else if (opNum == 1)
	{
		newOp->prevOpLbl = opHead;
		newOp->nextOpLbl = opHead;
		opHead->prevOpLbl = newOp;
		opHead->nextOpLbl = newOp;
	}
	else
	{
		newOp->prevOpLbl = opHead->prevOpLbl;
		newOp->nextOpLbl = opHead;
		opHead->prevOpLbl->nextOpLbl = newOp;
		opHead->prevOpLbl = newOp;
	}
	opNum++;
	return;
}

/* Free the list of operands. */
void freeOpList(void)
{
	oPtr p;

	while (opNum)
	{
		/* 'p' is temporary pointer to the head of the list. */
		p = opHead;

		if (opNum == 1)
			free(p);
		else
		{
			/* The 'next' pointer of the last operand become pointing to the second operand. */
			opHead->prevOpLbl->nextOpLbl = opHead->nextOpLbl;

			/* The 'prev' pointer of the second operand become pointing to the last operand. */
			opHead->nextOpLbl->prevOpLbl = opHead->prevOpLbl;

			/* The head of the list become pointing to the second operand. */
			opHead = opHead->nextOpLbl;

			/* Free the operand node that the head of the list was poiting to. */
			free(p);
		}
		opNum--;
	}
}


/* fillHoles: is manage the creataion of the extern file, And all the
adjustments between the label operand list and the dinamic operands list. */
void fillHoles(char* fileName)
{
	/* 'flagCreatExt' holds:
	0 if there was no extern directives.
	1 if the file is open.
	2 if the opening file failed. */
	int flagCreatExt = 0;
	int i = 0, ic = 0, addr = 0, maxBit = 0, minBit = 0, res = 0;
	char nameOpLbl[MAX_LABEL_LENGTH + 2]; /* +2 for new-line character and EOF character. */
	
	FILE *fext = openFileWithSuffix(fileName, ".ext");/* Creating the extern file. */
	if (fext == NULL)
		return; /* Opening file failed. */

	oPtr op = opHead;
	ptr lbl;

	/* This loop goining over all operand list and adjast each operand the address. */
	for (i = 0; i < opNum; op = op->nextOpLbl, i++)
	{
		res = 0;

		/*'nameOpLbl' is holding the label name. */
		strcpy(nameOpLbl, op->name);

		/* Search for a label in the name like the operand. */
		if ((lbl = isExistingLabel(nameOpLbl)) == NULL)
		{
			/* Not found a label. */
			lineNum = op->lineNmbr;
			storeErr("Label name '%s' not found.", nameOpLbl);
			continue;
		}
		/* lbl is now apointer to a label. */

		lineNum = lbl->lineNumber; /* Change temporry the global lineNum to holds
								   the line number where the label was reading from.
								   It's part is for the method sortErr. */

		addr = lbl->address; /* The address of the label given to 'addr'. */

		ic = op->indexIC;/* The address of the operand given to 'ic'. */

		if (op->isDinam && lbl->flagExtern)
		{
			/* If the label is extern and used as a dinmic label.*/
			storeErr("Label before dinamic operand can't be extern.", nameOpLbl);
			continue;
		}

		else if (op->isDinam) /* operand is dinamic. */
		{
			if (EC == 0)
			{
				unsigned int isBitOn;
				minBit = op->minIndexBit;
				maxBit = op->maxIndexBit;

				/* Store in 'res' the decima number from the desirable range. */
				res = getNumberInRange(minBit, maxBit, addr);

				/* Checks if the last bit was on in the label address. */
				isBitOn = lines[addr - FIRST_ADDRESS].bitim.allBits.all & (1 << maxBit);

				/* Checks if is needed to compelte "ones". */
				if (isBitOn != 0)
					res = completUnsigned((unsigned)res);

				/* in the operabd address -'ic' store the result. */
				lines[ic].bitim.otherBits.dest = (unsigned)res;
			}
			else /* There was an error. */
				continue;
		}

		else if (lbl->flagExtern) /* operand is extern. */
		{
			if (flagCreatExt == 0) 
				flagCreatExt = 1;/* The first extern label. */ 

			/* Add the a label to the extern file. */

			char* result = malloc(sizeof(char)*MAX_CHAR_IN_SPEC_BASIS);
			if (result == NULL)
			{
				printf("error: Malloc failed.");
				exit(1);
			}

			/* 'result' - holds the string represent the address in special basis. */
			transition(ic + FIRST_ADDRESS, 3, result);

			/* Writing to the extern file the name of label and address. */
			fprintf(fext, "%s \t %s\n", lbl->name, result);

			free(result);
		}
		else /* Operand is semple label(not dinamic or extern).*/
		{
			/* Insert the address from label list. */
			lines[ic].bitim.otherBits.dest = addr;
		}

		/* Initialized ERA bits */
		if (lbl->flagExtern)
		{
			lines[ic].bitim.otherBits.e_r_a = 1;
		}
		else if (!lbl->flagExtern && !lbl->flagOper && !op->isDinam)
		{
			lines[ic].bitim.otherBits.e_r_a = 2;
		}
	}

	lineNum = 0; /* Reset 'lineNum'. */

	fclose(fext);

	if (flagCreatExt == 0)
		myRemoveFile(fileName, ".ext");
}


