
/* ======= Includes ======= */

#include "dataStructhers.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/* ======= Global Data Structhers & Global Variables ======= */

extern oPtr opHead;
extern ptr labelHead;
extern int opNum;
extern int IC;
extern int labelNum;
extern int lineNum;
extern int EC;
extern encodingWord lines[MAX_LINES_NUM];

/* ======= Methods ======= */

/* Declared in  file " useful.c ". */
FILE* openFileWithSuffix(char* fileName, char *end);
int getNumberInRange(int minBit, int maxBit, int address);
int unsigned completUnsigned(int unsigned res);

/* Declared in  file " sortError.c ". */
void storeErr(const char *lastArg, ...);

/* Declared in file " main.c ". */
void myRemoveFile(char* fileName, char *suffix);

/* Declared in file " transBasis.c ". */
void transition(int num, int complete, char* res);

