/*
This file manages the assembling process.
It calls the first and second read methods, and creates the object files.

=======================
Author: Hagay Enoch
ID:     203089917
=======================
*/

#include "main.h"

/* ========== Declarations Of Global Variables & Global Data Structures =========== */

/* Erorrs */
error errList[MAX_LINES_NUM];
int EC = 0;
bool openErr = FALSE;

/* Labels List*/
ptr labelHead;
int labelNum = 0;

/* Data */
encodingWord lines[MAX_DATA_NUM];
int dataMem[MAX_DATA_NUM];
int IC = 0, DC = 0, numOfErrors = 0, lineNum = 0;

/* Operand List */
oPtr opHead;
int opNum = 0;

/* ====== Methods ====== */

/* resetAllData: Reset all globals and data structhers for next assembly file. */
void resetAllData()
{
	int i = 0;

	freeOpList();
	freeLabelList();

	/* Reset all error array. */
	for (i = 0; i < EC; i++)
	{
		errList[errList[i].lineNmbr].isErr = FALSE;
		errList[i].lineNmbr = 0;
		free(errList[i].str); /* Free the memory alocated by "malloc". */
		errList[i].str = NULL;
	}

	/* Reset all the bits in 'lines'.*/
	for (i = 0; i <= DC+IC; i++)
		lines[i].bitim.allBits.all = 0;

	/* Reset the data memory. */
	for (i=0; i < DC; i++)
		dataMem[i] = 0;
	
	EC = 0;
	IC = 0;
	DC = 0;
	numOfErrors = 0;
	lineNum = 0;
	openErr = FALSE;
}


/* createObjFile: Creating the object file. */
void createObjFile(char* fileName)
{
	int i = 0;
	FILE* fp = openFileWithSuffix(fileName, ".ob");

	if(fp == NULL)
		return;

	char* resultOne = malloc(sizeof(char)*(MAX_CHAR_IN_SPEC_BASIS + 1));
	char* resultTwo = malloc(sizeof(char)*(MAX_CHAR_IN_SPEC_BASIS + 1));

	if (resultOne == NULL || resultOne == NULL)
	{
		printf("error: Malloc failed.");
		exit(1);
	}

	/* Insert the strings represents - 'IC' number to 'resultOne' 
		,and 'DC' number to 'resultTwo' in special basis. */
	transition(IC, 5, resultOne);
	transition(DC, 5, resultTwo);

	/* Printing nubmer of instraction lines and number of data lines in special basis. */
	fprintf(fp, "%s \t %s\n\n", resultOne, resultTwo);

	free(resultOne);
	free(resultTwo);

	while (i < IC + DC)
	{
		resultOne = malloc(sizeof(char)*(MAX_CHAR_IN_SPEC_BASIS + 1));
		resultTwo = malloc(sizeof(char)*(MAX_CHAR_IN_SPEC_BASIS + 1));
		if (resultOne == NULL || resultOne == NULL)
		{
			printf("error: Malloc failed.");
			exit(1);
		}
		
		/* 'tmp' holds the decimal number of a line of bits. */
		int tmp = lines[i].bitim.allBits.all;

		/* Insert to 'resultOne' and 'resultTwo' the
		strings represents the bits in special basis. */
		transition(i + FIRST_ADDRESS, 3, resultOne);
		transition(tmp, 5, resultTwo);

		/* Printing the address number and the 15 bits in special basis. */
		fprintf(fp, "%s \t %s\n", resultOne, resultTwo);

		free(resultOne);
		free(resultTwo);
	
		i++;
	}
	fclose(fp);
}


/* createdFiles: Print which output files created. */
void createdFiles(char *fileName)
{
	if (fileExist(fileName, ".ob"))
		printf("Successfully create a file \"%s.ob\".\n", fileName);

	if (fileExist(fileName, ".ext"))
		printf("Successfully create a file \"%s.ext\".\n", fileName);

	if (fileExist(fileName, ".ent"))
		printf("Successfully create a file \"%s.ent\".\n", fileName);
}

/* myRemoveFile: remove a file with a suffix. */
myRemoveFile(char* fileName, char *suffix)
{
	char result[MAX_FILE_NAME_LENGTH + 5];
	strcpy(result, fileName);
	strcat(result, suffix);

	remove(result);
}

/* removAllFiles: remove all files if they exists. */
void removAllFiles(char *fileName)
{
	if (fileExist(fileName, ".ob"))
		myRemoveFile(fileName, ".ob");

	if (fileExist(fileName, ".ent"))
		myRemoveFile(fileName, ".ent");

	if (fileExist(fileName, ".ext"))
		myRemoveFile(fileName, ".ext");
}

/* encodeFile: Encoding a file, and creating the output files. */
void encodeFile(char *fileName)
{
	char result[MAX_FILE_NAME_LENGTH + 5];
	strcpy(result, fileName);
	strcat(result, ".as");

	/* Remove all output files if exists from early program use. */
	removAllFiles(fileName);

	/* Open File */
	FILE *file = fopen(result, "r");

	/* Not found a file with the given name. */
	if (file == NULL)
	{
		printf("Open file name \"%s\" failed.\n", result);
		return;
	}
	
	printf("Successfully opened file name \"%s.as\".\n", fileName);

	/* First Read */
	firstFileRead(file);
	
	lineNum = 0;

	/* Get the file pointer to the start of the file. */
	rewind(file);

	/* Second Read */
	secondFileRead(file, fileName);

	if (EC == 0) /* True if there was no error in spsific lines. */
	{ 
		if (!openErr) /* True if there was no error in openings files. */
		{
			/* Create an object file. */
			createObjFile(fileName);
		
			/* Check again if the object file succesefully created. */
			if (!openErr)
			{
				/* Print which output files created. */
				createdFiles(fileName);
			
				fclose(file);

				resetAllData();
				return;
			}
		}
	}
	
	/* There is an error. */
	
	if (EC != 0 && !openErr)
	{
		/* There is no errors of opening files, just errors in spcific lines. */
		fprintf(stderr, "\nFound errors in file \"%s.as\":\n", fileName);
		printAllErr();
		printf("A total of %d erorrs.\n", EC);
	}

	removAllFiles(fileName);

	fclose(file);

	resetAllData();
}


/* main: Calls the "encodeFile" method for each file name in the command list. */
int main(int argc, char *argv[])
{
	int i;

	if (argc < 2)
	{
		printf("Commend line is empty.\n");
		return 1;
	}

	for (i = 1; i < argc; i++)
	{
		/* Check if the file name is too long. */ 
		if (strlen(argv[i]) < MAX_FILE_NAME_LENGTH)
		{
			encodeFile(argv[i]);
			printf("\n");
		}
		else
			printf("Name of file number %d is too long.\n\n", i);
	}

	return 0;
}
