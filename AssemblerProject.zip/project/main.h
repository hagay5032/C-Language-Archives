
/* ======= Includes ======= */

#include "dataStructhers.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/* ======= Methods ======= */

/* Declared in file " firstReadFile.c ". */
void firstFileRead(FILE *file);

/* Declared in file " secondReadFile.c ". */
void secondFileRead(FILE *file, char* fileName);
void freeOpList();

/* Declared in file " useful.c ". */
int printAllErr();
FILE* openFileWithSuffix(char* fileName, const char *end);
bool fileExist(char* fileName, const char *suffix);

/* Declared in file " transBasis.c ". */
void transition(int num, int complete, char* res);

/* Declared in file " labelTable.c ". */
void freeOpList(void);
void freeLabelList(void);
