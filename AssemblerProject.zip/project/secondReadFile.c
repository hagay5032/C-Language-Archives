/*
This file is the second read of an assembly file.
It's detect errors, And if was no any errors:
-	it's create the extern file and the entry file.
-	it's save data to the creation of the object file.

=======================
Author: Hagay Enoch
ID:     203089917
=======================
*/

#include "secondReadFile.h"

/* conectData: Conect the instraction lines and the data lines. */
void conectData()
{
	int i = 0;
	while (i < DC)
	{
		lines[IC + i].bitim.allBits.all = dataMem[i];
		i++;
	}
}


/* secondFileRead: manages all arrangements of address in tha array 'lines'.
	Also reading the file again, line by line, search for entries,
	and creates the entries file if found. */
void secondFileRead(FILE *file, char* fileName)
{
	/* 'flagCreatEnt' holds: 0 if there was no entry directives, or 1 if there was.*/
	int flagCreatEnt = 0;
	char string[MAX_LINE_LENGTH + 2];
	char *restOfLine;
	int direct = 0;
	
	FILE* fent = openFileWithSuffix(fileName, ".ent");
	if (fent == NULL)
		return; /* Opening file failed. */

	adjustAddresses(); /* Adjust all addresses of the data memory. */

	conectData(); /* Conect the instraction and the data. */

	/* Adjust all label operands addresses, and creats the extern file. */
	fillHoles(fileName);

	freeOpList(); /* Free the operand list for holding names of entry labels. */

	/* second Read Algoritm */
	/* Read lines and create the entries file */
	while (!feof(file))
	{
		lineNum++;

		if (readLine(file, string))
		{
			direct = 0;

			if (errList[lineNum].isErr)
				continue;

			if (isCommentOrEmpty(string))
				continue;

			/* Check if there is a label in the start of the line. And if so
				skip the label by pointing 'restOfLine' to the rest of the line. */
			if (restOfLine = strchr(string, ':'))
				restOfLine++;
			else
				restOfLine = string;

			if (restOfLine)
				trimStr(&restOfLine);

			/* Check existence of directives. if was found:
			- 'restOfLine' hold the rest of line after directive.
			- direct gets 1,2,3,4 represent string,data,entry,extern respectively. */
			if (thereIsADirect(&restOfLine, &direct))												
			{
				if(direct == 3) /* Entry */
				{
					int addrs;
					ptr pt;

					/* Check if there is an error in the current line. */
					if (errList[lineNum].isErr)
						continue;
									
					/* Checks if there is a label name after entry. */
					if (restOfLine == NULL || isWhiteSpaces(restOfLine))
					{
						storeErr("Entry directive must be with a symbol after it.");
						continue;
					}
					
					/* Check if the entry was used as a label. */
					if ((pt = isExistingLabel(restOfLine)) == NULL)
					{
						/* There is no label with that name. */
						storeErr("Symbol not found.");
						continue;
					}
					else
					{
						/* Check if there was allrdy a decleration of the entry. */
						if (existsEntry(restOfLine))
						{
							storeErr("There is double decleration of an entry directive name- '%s'.", restOfLine);
							continue;
						}

						else /* The entry is legal. */
						{
							if (flagCreatEnt == 0)
								flagCreatEnt = 1; /* The first entry label. */

							/* Creat a node of operand. */
							oPtr opLbl = (oPtr)malloc(sizeof(operand));
							if (opLbl == NULL)
							{
								printf("error: Malloc failed.");
								exit(1);
							}

							/* Initialized name of entry label. */
							strcpy(opLbl->name, restOfLine);
							addOpLbl(opLbl);

							if (EC == 0)
							{
								/* Insert a entry to the entries line. */
								char* result = malloc(sizeof(char)*MAX_CHAR_IN_SPEC_BASIS);
								if (result == NULL)
								{
									printf("error: Malloc failed.");
									exit(1);
								}

								addrs = pt->address; /* 'addrs' hold the label address. */

								/* 'result' become holding the string representing the address. */
								transition(addrs, 3, result);

								/* Writing into the entries file a label name and address. */
								fprintf(fent, "%s \t %s\n", restOfLine, result);

								free(result);
							}
						}
					}
				}
			}
		}
	}
	fclose(fent);

	if (flagCreatEnt == 0)
		myRemoveFile(fileName, ".ent");

	return;
}
