
/* ======= Includes ======= */

#include "dataStructhers.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ======= Global Data Structhers & Global Variables ======= */

extern error errList[MAX_LINES_NUM];
extern encodingWord lines[MAX_LINES_NUM];
extern int dataMem[MAX_DATA_NUM];
extern int IC;
extern int DC;
extern int lineNum;
extern int EC;


/* ======= Methods ======= */

/* Declared in  file " useful.c ". */
bool isCommentOrEmpty(char *line);
bool thereIsADirect(char** line, int* value);
bool isWhiteSpaces(char *str);
void trimStr(char **ptStr);
FILE* openFileWithSuffix(char* fileName, char *end);
bool existsEntry(char *labelName);

/* Declared in  file " sortError.c ". */
void storeErr(const char *lastArg, ...);

/* Declared in  file " transBasis.c ". */
void transition(int num, int complete, char *res);

/* Declared in  file " firstReadFile.c ". */
bool readLine(FILE *file, char *str);

/* Declared in  file " labelTabel.c ". */
void addOpLbl(oPtr newOp);
void adjustAddresses();
void fillHoles(char* fileName);
ptr isExistingLabel(char *labelName);
void freeOpList(void);

/* Declared in  file " main.c ". */
myRemoveFile(char* fileName, char *suffix);


