/*
This file sort all errors to be printing by the order of the line numbers.

=======================
Author: Hagay Enoch
ID:		203089917
=======================
*/

#include "sortError.h"


/* Returns true if there is no error in the current line. */
bool isErrorInLine()
{
	return errList[lineNum].isErr;
}


/* Store an error in the array of errors: 'errList' with prefix of the line number. */
void storeErr(const char *lastArg, ...)
{
	if (!isErrorInLine())
	{
		char *temp = malloc(sizeof(char)*(MAX_LINE_LENGTH + 2));

		if (temp == NULL)
		{
			printf("error: Malloc failed.");
			exit(1);
		}

		va_list ap;
		va_start(ap, lastArg);

		/* Set the prefix of temp. */
		sprintf(temp, "error line [%d]: ", lineNum);

		/* Set the error massage of temp after the prefix. */
		vsprintf(temp + strlen(temp), lastArg, ap);

		/* Set "end of string" in the end. */
		sprintf(temp + strlen(temp), "\0");

		va_end(ap);

		/* Set the string. */
		errList[EC].str = temp;

		/* Turn on flag- there is an error in the current( 'lineNum' ) line. */
		errList[lineNum].isErr = TRUE;

		/* Set the line number. */
		errList[EC].lineNmbr = lineNum;

		EC++;
	}
}


/* writelines: prints all strings to the standart error file. */
void writelines(int nlines)
{
	int i;

	for (i = 0; i < EC; i++)
		fprintf(stderr, "%s\n", errList[i].str);
}

/* swap: is swaping between two errors in the 'errList'. */
void dubleSwap(int i, int j)
{
	int tmp;

	/* swap two strings. */
	char * temp = errList[i].str;
	errList[i].str = errList[j].str;
	errList[j].str = temp;

	/* swap two line numbers. */
	tmp = errList[i].lineNmbr;
	errList[i].lineNmbr = errList[j].lineNmbr;
	errList[j].lineNmbr = tmp;

}

/* quSort: Quick sort algoritm, arrange all errors by the line number. */
void quSort(int left, int right)
{
	int i, last;

	if (left >= right)
		return;
	dubleSwap(left, (left + right) / 2);
	
	last = left;

	for (i = left + 1; i <= right; i++)
	{
		if (errList[i].lineNmbr <= errList[left].lineNmbr)
		{
			/* if the line number in index 'i' is less then the line number in index 'left'.*/
			dubleSwap(++last, i);
		}
	}
	dubleSwap( left, last);
	
	quSort( left, last - 1);
	quSort( last+1, right);
}

/* printAllErr: manage the printing of all erros in order. */
int printAllErr()
{
	quSort(0, EC-1);
	
	writelines(EC);
	
	return 0;
}

