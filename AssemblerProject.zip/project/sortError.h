
/* ======= Includes ======= */

#include "dataStructhers.h"
#include "stdio.h"
#include "stdlib.h"
#include <stdarg.h>

/* ======= Global Data Structhers & Global Variables ======= */

extern error errList[MAX_LINES_NUM];
extern int lineNum;
extern int EC;
extern bool openErr;
