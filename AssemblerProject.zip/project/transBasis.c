/*
This file manages the transition of decimal numbers to the special basis.

=======================
Author: Hagay Enoch
ID:		203089917
=======================
*/

/* ======= Includes =======*/

#include "dataStructhers.h"
#include <stdlib.h>

/* ======= Data Structures ======= */

char specialBasis[8] = { '!','@','#','$','%','^','&','*' };

/* ======= Method ======= */

/* reverseNum: return a integer represent the reverse number. */
/* And store the length's number in 'len'. */
int reverseNum(int num, int *len)
{
	int upsideDown = 0, length = 0;
	
	while (num > 0)
	{
		upsideDown = upsideDown*10 + (num % 10);
		num = num / 10;
		length++;
	}

	*len = length; /* store the length in 'len'. */

	return upsideDown;
}

/* specialConvert: convert a octal number to special octal number. */
/* Store the string in 'result'. */
/* 'com' is the length of the desirable string. */
void specialConvert(int num, int com, char *result)
{
	int i = 0, tmp = 0, len = 0;

	num = reverseNum(num, &len);

	while (com > 0)
	{
		if (com - len > 0) /* Completing zeros. */
			result[i] = '!';
		else
		{
			tmp = num % 10;
			result[i] = specialBasis[tmp];
			num = num / 10;
		}	
		i++;
		com--;
	}
	result[i] = '\0';
	return;
}

/* transition: convert decimal number to octal number. */
void transition(int num, int complete, char* res)
{
	int rest = 0, i = 1;

	while (num > 0)
	{
		rest = rest + (num % 8)*i;
		num = num / 8;
		i *= 10;
	}

	specialConvert(rest,complete, res);
}
