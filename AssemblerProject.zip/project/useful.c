/*
This file contains useful functions for all files.

=======================
Author: Hagay Enoch
ID:		203089917
=======================
*/

#include "useful.h"

/*===== Directive List ======*/
const char *methods[] =
{
	"a"  ,
	"r"  ,
	"w" ,
	"a+"  ,
	"r+"  ,
	"w+" ,
	NULL
};

const char *directArr[] =
{
	"string"  ,
	"data"  ,
	"entry" ,
	"extern" ,
	"STRING"  ,
	"DATA"  ,
	"ENTRY" ,
	"EXTERN" ,
	NULL  /* represent the end of the array */
};

/*===== Command List ======*/

const command cmdArr[] =
{	/* Opcode | Name | NumOfParams */
	{ 0,"mov", 2 } ,
	{ 1,"cmp", 2 } ,
	{ 2,"add", 2 } ,
	{ 3,"sub", 2 } ,
	{ 4,"not", 1 } ,
	{ 5,"clr", 1 } ,
	{ 6,"lea", 2 } ,
	{ 7,"inc", 1 } ,
	{ 8,"dec", 1 } ,
	{ 9,"jmp",  1 } ,
	{ 10,"bne", 1 } ,
	{ 11,"red", 1 } ,
	{ 12,"prn", 1 } ,
	{ 13,"jsr", 1 } ,
	{ 14,"rst", 0 } ,
	{ 15,"stop", 0 } ,
	{ 16 } /* represent the end of the array */
};


/* ====== Methods ====== */


/* completUnsigned: complete the zeros after the last one in 'res' to ones.
Return an int represent the unsinged 13 bits. */
int unsigned completUnsigned(int unsigned res)
{
	int i = 13;

	/* This loop start from the last bit( 13 bit) and turn
	on  all zero bits until encountered one. */
	while (0 == (res & (1 << i)) && i > 0)
	{
		res = (res | (1 << i));
		i--;
	}
	return res;
}


/* Removes spaces from start */
void trimLeftStr(char **str)
{
	/* Returns if it's NULL */
	if (!str)
		return;
	
	/* Get 'str' to the start of the actual text */
	while (isspace(**str))
		++*str;
}

/* Removes all the spaces from the edges of the string 'str'. */
void trimStr(char **str)
{
	char *end;

	/* Returns if it's NULL or empty string */
	if (!str || **str == '\0')
	{
		return;
	}

	trimLeftStr(str);

	/* 'end' is pointing to the last char in str, before '\0' */
	end = *str + strlen(*str) - 1;

	/* Remove spces from the end. */
	while (end != *str && isspace(*end))
		*end-- = '\0';
}


/* Returns if the strParam is a legal string param (enclosed in quotes), and remove the quotes. */
bool isLegalStringParam(char **str)
{
	/* check if the string param is enclosed in quotes */
	if ((*str)[0] == '"' && (*str)[strlen(*str) - 1] == '"')
	{
		/* remove the quotes */
		(*str)[strlen(*str) - 1] = '\0';
		++*str;
		return TRUE;
	}

	if (**str == '\0')
		storeErr("No parameter.");

	else
		storeErr("The parameter for .string must be enclosed in quotes.");

	return FALSE;
}

/* Returns if 'str' contains only white spaces. */
bool isWhiteSpaces(char *str)
{
	while (*str)
		if (!isspace(*str++))
			return FALSE;
	
	return TRUE;
}


/* Returns true if str contains only one word. */
bool isOneWord(char *str)
{
	/* Skip the spaces at the start */
	trimLeftStr(&str);
	
	/* Skip the text at the middle */
	while (!isspace(*str) && *str) { str++; }	

	/* Returns true if it's the end of the text or not. */
	return isWhiteSpaces(str);
}


/* Returns if str is a register name, and update value to be the register value. */
bool isRegister(char *str, int *value)
{
	if (str[0] == 'r'  && str[1] >= '0' && str[1] - '0' <= MAX_REGISTER_DIGIT && str[2] == '\0')
	{
		/* Update value if it's not NULL. */
		if (value)
			*value = str[1] - '0'; /* -'0' To get the actual number the char represents */
		return TRUE;
	}
	return FALSE;
}


/* Returns the ID of the command how much to the 'cmdName', or -1 if there isn't such command. */
int getCmdId(char *cmdName)
{
	int i = 0;
	while (cmdArr[i].name)
	{
		if (strcmp(cmdName, cmdArr[i].name) == 0)
			return i;
		i++;
	}
	return -1;
}


/* Returns if labelStr is a legal label name. */
bool isLegalLabel(char *labelStr)
{
	if (labelStr == NULL)
		return FALSE;
	
	int labelLength = strlen(labelStr);

	/* Check if the label size is good */
	if (labelLength > MAX_LABEL_LENGTH)
	{
		storeErr("Label is too long. Max label name length is %d.", MAX_LABEL_LENGTH);
		return FALSE;
	}

	/* Check if the label isn't an empty string */
	if (*labelStr == '\0')
	{
		storeErr("Label name is empty.");
		return FALSE;
	}

	/* Check if the 1st char is a letter. */
	if (isspace(*labelStr))
	{
		storeErr("Label must start at the start of the line.");
		return FALSE;
	}

	/* Check if there are two wards. */
	if (!isOneWord(labelStr))
	{
		storeErr("label must be just one word.");
		return FALSE;
	}

	/* Check if the 1st char is a letter. */
	if (!isalpha(*labelStr))
	{
		storeErr("first char must be a letter.");
		return FALSE;
	}

	/* Check if it's not a name of a register */
	if (isRegister(labelStr, NULL)) /* NULL since we don't have to save the register number */
	{
		storeErr("don't use a name of a register.");
		return FALSE;
	}

	/* Check if it's not a name of a command */
	if (getCmdId(labelStr) != -1)
	{
		storeErr("don't use a name of a command.");
		return FALSE;
	}

	/* Checks each digit if legal. */
	while (strlen(labelStr))
	{
		if (!isalpha(*labelStr) && !isdigit(*labelStr))
		{
			storeErr("char must be a letter or a digit.");
			return FALSE;
		}
		labelStr++;
	}

	/* The label is legal. */
	return TRUE;
}


/* isDirect: return trur if 'word' is a directive. */
bool isDirect(char* word, int* val) 
{
	int i;
	/* Search for directive. */
	for (i = 0; directArr[i]; i++)
		if (strcmp(word, directArr[i]) == 0)
		{
			*val = i % 4 + 1;
			return TRUE;
		}
	return FALSE;
}


/* thereIsADirect: Returns true if the pointer to string 'line' is a directive.
   Also if was found a directive:
   -		Makes 'line' point to the rest of the string without the directive. 
   -		Store 1,2,3,4 each represnt - (string=1/data=2/entry=3/extern=4) in Value. */
bool thereIsADirect(char** line, int* value)
{
	if (**line == '.')
	{
		/* Drop the "dot" . */
		(*line)++;

		/* 'endofword' holds the first word without the dot and the rest of the line. */
		char* endOfWord = strtok(*line, " \t");
		
		/* 'line' point to the rest of the string. */
		*line = strtok(NULL, "\0");
		
		return isDirect(endOfWord, value);
	}
	return FALSE;
}


/* Returns true if the string 'line' represent a comment or an empty line. */
/* If the first char is ';' but it's not at the start of the line, it returns true */
bool isCommentOrEmpty(char *line)
{
	char *startOfText = line;

	if (*line == ';')/* Comment. */
		return TRUE;

	trimLeftStr(&startOfText);
	
	if (*startOfText == '\0')/* Empty line. */
		return TRUE;

	if (*startOfText == ';')
	{
		storeErr("Comments must start with ';' at the start of the line.");
		return TRUE;
	}

	return FALSE;
}


/* Returns true if the string 'str' is a command name 
	and if so - puts the opcode in the parameter 'value'.*/
bool isFuncName(char* str, int *value)
{
	int i = 0;

	while (i < 16)
	{
		if (strcmp(cmdArr[i].name, str) == 0)
		{
			*value = i;
			return TRUE;
		}
		i++;
	}
	return FALSE;
}


/* Returns true if the two numbers creat a lrgal range.*/
bool isLegalRange(int* numOne, int* numTwo)
{
	/* Set the biggest number in 'numTwo' and the litel in numOne. */
	if (*numOne > *numTwo)
	{
		int temp = *numOne;
		*numOne = *numTwo;
		*numTwo = temp;
	}

	/* Check if the two numbers creating legal range. */
	if (*numOne < 15 && *numTwo < 15 && *numOne >= 0 && *numTwo >= 0)
		if (*numTwo - *numOne < 13)
			return TRUE;

	return FALSE;
}



/* Returns true if the string 'str' is a dinamic legal operand. 
	Puts the label name before the range in 'labelName',
	and the two numbers of the range in numOne and numTwo. */
bool isDinamic(char *str, int* numOne, int* numTwo)
{
	int value = 0;
	char *restF;
	char *restSec;
	char *end;

	if (restF = strchr(str, '['))
	{
		if (restF == NULL)
			return FALSE;
		
		/* Cut the string to be just the label name. */
		*restF = '\0'; 

		trimStr(&str);

		if (isLegalLabel(str))

			/* Remove the first Bracket */
			restF++;

		trimLeftStr(&restF);
		
		if (!isdigit(*restF))
		{
			storeErr("first parameter in range is illegal");
			return FALSE;
		}
		
		/* Stores the first number in 'numOne'. */
		*numOne = (int)strtol(restF, &restSec, 10); 

		if (restSec == NULL || isWhiteSpaces(restSec))
		{
			storeErr("The parameter in the brackets is illegal.");
			return FALSE;
		}

		trimLeftStr(&restSec);

		if (restSec[0] == '-')
		{
			/* Remove the hyphen-minus */
			restSec++;

			trimLeftStr(&restSec);

			if (!isdigit(*restSec))
			{
				storeErr("second parameter in range is illegal");
				return FALSE;
			}

			/* Stores the second number in 'numOne'. */
			*numTwo = (int)strtol(restSec, &end, 10);

			if (end == NULL || isWhiteSpaces(end))
			{
				storeErr("The parameters in the brackets is illegal.");
				return FALSE;
			}

			/* Terminate all white spaces around the rest of the string. */
			trimStr(&end);

			if (strcmp(end, "]") != 0)
			{
				storeErr("The parameters near the brackets is illegal.");
				return FALSE;
			}
		}
		else 
		{
			storeErr("The range in the brackets is illegal.");
			return FALSE;
		}

		/* Check legalization of the numbers and range. */
		if (isLegalRange(numOne, numTwo))
			return TRUE;
		else
			storeErr("The range in the brackets is illegal.");
		return FALSE;
	}
	return FALSE;
}


/* Returns the name of the command how much to the 'opcode' , or null if there isn't such opcode. */
char *getNameOfCmd(int opcode)
{
	int i = 0;

	while (cmdArr[i].name)
	{
		if (opcode == cmdArr[i].opcode)
			return cmdArr[i].name;
		i++;
	}
	return NULL;
}



/* Returns the number of parameters of the command how much to the 'opcode', or -1 if there isn't such opcode. */
int getCmdNumParm(int opcode)
{
	int i = 0;

	while (cmdArr[i].name)
	{
		if (opcode == cmdArr[i].opcode)
			return cmdArr[i].numOfParams;
		i++;
	}
	return -1;
}


/* Finds label and put the name of the label in 'labelName'. */
/* Returns a pointer to the next char after the label, or NULL is there isn't a legal label. */
char *thereIsValidLabel(char *line)
{
	char *labelEnd = strchr(line, ':');

	/* Find the label (or return NULL if there isn't). */
	if (!labelEnd)
	{
		return NULL;
	}
	*labelEnd = '\0';

	if (!isLegalLabel(line))
	{
		/* Illegal label name. */
		return NULL;
	}

	/* Check if label was alrdy declared. */
	if (isExistingLabel(line) != NULL)
	{
		storeErr("Label already exists.");
		return NULL;
	}

	return labelEnd + 1; /* +1 to make it point at the next char after the '\0' . */
}

/* fileExist: return a non-zero value if the a file is exists.*/
bool fileExist(char* fileName, const char *suffix)
{
	FILE* fp;
	char result[MAX_FILE_NAME_LENGTH + 5];
	
	if (fileName == NULL) /* Check if there waas enter a null string. */
		return FALSE;

	/* Copy name of file into 'result'. */
	strcpy(result, fileName);

	/* Add suffix. */
	strcat(result, suffix);

	fp = fopen(result, "r");

	if (fp != NULL)
		fclose(fp);
	return (fp != NULL);
}


/* openFileWithSuffix: open files with a desirable suffix for writing. */
FILE* openFileWithSuffix(char* fileName, const char *end)
{
	FILE* fp = NULL;
	char result[MAX_FILE_NAME_LENGTH + 5]; /* +5 for desirable suffix. */

	/* Copy the file name into result. */
	strcpy(result,fileName);

	/* Add the suffix to the file name. */
	strcat(result, end);
	 
	fp = fopen(result, "w"); 

	if (fp == NULL) /* There was an error in the opening file try. */
	{
		printf("Create file name \"%s\" failed.\n", result);
		openErr = TRUE;
	}

	return fp;
}


/* powerTwo: Return 2 power 'k'. */
int powerTwo(int k)
{
	if (k>0)
		return 2 * powerTwo(k - 1);
	return 1;
}


/* getNumberInRange: Return an int represent the number
in the range of minBit and maxBit. */
int getNumberInRange(int minBit, int maxBit, int address)
{
	int j = minBit, k = 0, isBitOn = 0, res = 0;
	while (j <= maxBit)
	{
		if (isBitOn = (lines[address - FIRST_ADDRESS].bitim.allBits.all & (1 << j)))
			res += powerTwo(k);
		k++;
		j++;
	}
	return res;
}
