
/* ======== Includes ======== */
#include "dataStructhers.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

/* ======= Global Data Structhers & Global Variables ======= */

extern encodingWord lines[MAX_DATA_NUM];
extern error errList[MAX_LINES_NUM];
extern int lineNum;
extern int EC;
extern bool openErr;

/* ======== Methods ======== */

/* from file " sortError.c ". */
void storeErr(const char *lastArg, ...);

/* from file " labelTable.c ". */
ptr isExistingLabel(char *labelName);
