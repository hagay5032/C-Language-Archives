/**
mmn22.c
Purpose: Calculator of mathmatical operation on matrices(4x4).

@author Hagay Enoch
@version 1.0 15/05/16
*/


#include <stdio.h>
#include "mat.h" 		

struct {
	char *name;
	void(*func)(void);
}cmd[] = {
	{ "read_mat",read_mat },
	{ "print_mat",print_mat },
	{ "add_mat",add_mat },
	{ "sub_mat",sub_mat },
	{ "mul_mat",mul_mat },
	{ "mul_scalar",mul_scalar },
	{ "trans_mat",trans_mat },
	{ "stop",stop },
	{ "#",NULL }
};

void main(void)
{
	char command[30];
	int i = 0;
	printf("Hello this program is a calcuator for matrix 4X4 and there is a seven diffrenet's command's.\nAll command's need to be written the same way- first the name of the command and with \na one space bar between the command's name and the parameters, the parameters needs to\nbe in a row with one comma between any diffrenets paramters\nThe commands are:\n\n1. read_mat matrix-name,a seires of real numbers in a row separated by one comma \n\tThe command will enter the numbers to the desirable matrix. The leftmost number\n\tin the seires is enter to the cell (0,0), The second number is getting in to the \n\tcell (0,1) and so on...If was enter more then 16 parameters, the program is skiped \n\tthe extara parameters. If was enter less then 16 parameters, the programand will \n\tenter the numbers to the matrix and the rest parameters will be zeros.\n\n2.print_mat matrix-name\n\t The command print the values of the metrix to the screen.\n\n3.add_mat first matrix-name,second matrix-name,third matrix-name\n\tThe command sum the two firsts metrix and stores the result in the third metrix.\n\n4.sub_mat first matrix-name,second matrix-name,third matrix-name\n\tThe command subtract the second matrix from the first metrix and stores the \n\tresult in the third metrix.\n\n5.mul_mat first matrix-name,second matrix-name,third matrix-name\n\tThe command multiple the firsts two metrices and stores the result in the \n\tthird metrix.\n\n6.\"mul_scalar\" first matrix-name,a real number,second matrix-name\n\tThe command multiple the first matrix by the real number and stores the result \n\tin the second metrix.\n\n7.trans_mat first matrix-name,second matrix-name\n\tThe command perfoms \"reversal\" on the values of the first matrix and stores the \n\tresult in the second metrix. There is no change in the valuse of the first matrix.\n\n8.stop\n\tThe command will stop the program, And exit to the Operating System.\n");
	FOREVER
		if (scanf("%s", command) == 1) {
			for (i = 0; cmd[i].func != NULL; i++)
				if (strcmp(command, cmd[i].name) == 0)
					break;

			if (cmd[i].func == NULL) {
				printf("\"No such command\"\n");
				fgets(command, 80, stdin);
				printf("%s\n", command);
			}
			else
				(*(cmd[i].func))();
		}
}





