
#include "mat.h"
 

mat MAT_A, MAT_B, MAT_C, MAT_D, MAT_E, MAT_F;

struct {
	char *name;
	mat *matrix;
}mats[] = {
	{ "MAT_A",&MAT_A },
	{ "MAT_B",&MAT_B },
	{ "MAT_C",&MAT_C },
	{ "MAT_D",&MAT_D },
	{ "MAT_E",&MAT_E },
	{ "MAT_F",&MAT_F },
	{ "#",NULL }
};

typedef struct tnode {
	mat *first_parm;
	mat *second_parm;
	mat *result;
}parms;

parms temp_parm;



/**
This method cuts a white space befor and after a matrix names.
the method get a string and in the first not white space charater she   
@parm a string containing
*/
char* skip_white_spaces_bef_aft_matrix_name(char *m) {

	while (*m == '\t' || *m == ' ')/*Skip white space before matrix name. */
		m++;

	char *temp = m;/*temp hold adress of the first not white space charater*/
	int i;

	for (i = 0; i < 5 && *m != '\0'; i++, m++);/*proceed m 5 charaters to 
											   be in the end of the matrix name*/

	while (*m == '\t' || *m == ' ')/* Skip white space after the name of the the matrix. */
		m++;

	if (*m == '\n' || *m == '\0')
		*(temp + 5) = '\0';
	return temp;

}



/**
This method get a matrix name,
And return the adress of the disirable matrix.

@parm t is the place in the series of parameter that th user enter.
@parm m is the name of the matrix.
@return adress of matrix.
*/
mat *get_matrix_name(int t, char *m) {
	int i;
	if (m != NULL) {
		char *temp = skip_white_spaces_bef_aft_matrix_name(m);

		for (i = 0; mats[i].matrix != NULL; i++)
			if (strcmp(temp, mats[i].name) == 0)
				break;

		if (mats[i].matrix == NULL) {

			char* num[4] = { "First parameter-", "Second parameter-", "Third parameter-", " " };
			printf("\n\"ERROR:%sNo such matrix name\"\n", num[t]);
			return NULL;
		}
		else
			return mats[i].matrix;
	}
	printf("ERROR:too littel parameters\n");
	return NULL;
}



/**
This method get three matrices names, 
And adjust the adresses of each diesirable matrix, in the same order
in the local parametr "temp"- that holds the three adresses in the it's struct. 
@return 1 if all three adresses adjustments sucseesded. And 0 atherwise.
*/
int get_three_matrices_names(void) {
	char data[80];
	fgets(data, 80, stdin);
	char* ch = strtok(data, ",");
	if ((temp_parm.first_parm = get_matrix_name(0, ch)) != NULL) {
		ch = strtok(NULL, ",");
		if ((temp_parm.second_parm = get_matrix_name(1, ch)) != NULL){
			ch = strtok(NULL, "\0");
			if ((temp_parm.result = get_matrix_name(2, ch)) != NULL) {
						return 1;
			}
		}
	}
	return 0;
}



/**
This method get from the user a matrix name,
And print the values of the  to the diesimatrix to the screen.
*/
void print_mat(void) {
	char parameters[80];
	char *m = fgets(parameters, 80, stdin);

	if ((temp_parm.result = get_matrix_name(3, m)) != NULL) {
		int i, j;
		for (i = 0; i< SIZE; i++) {
			for (j = 0; j< SIZE; j++)
				printf("%5g ", (*temp_parm.result)[i][j]);
			putchar('\n');
		}
	}
}


/**
This method exit the program
*/
void stop(void) { exit(1); }


/**
This method get from the user a matrix name, and a seires of numbers,
And insert the numbers to the diesirable matrix.  
*/ 
void read_mat(void){
	char data[80];
	fgets(data, 80, stdin);
	char *m = strtok(data, ",");

	if ((temp_parm.result = get_matrix_name(0, m)) != NULL)
		get_data(temp_parm.result);
}


/**
This method get from the user three matrices,
And sum the first two matrices,Then put the result in the third.
*/
void add_mat(void) {
	int y = get_three_matrices_names();
	if (y) {
		int k = 0;
		int j = 0;
		for (k = 0; k< SIZE; k++)
			for (j = 0; j< SIZE; j++)
				(*temp_parm.result)[k][j] = (*temp_parm.first_parm)[k][j] + (*temp_parm.second_parm)[k][j];
	}
}


/**
This method get from the user three matrices,
And subtruct the first two matrices,Then put the result in the third.
*/
void sub_mat(void) {
	int i = get_three_matrices_names();
	if (i) {
		int k = 0;
		int j = 0;
		for (k = 0; k< SIZE; k++)
			for (j = 0; j< SIZE; j++)
				(*temp_parm.result)[k][j] = (*temp_parm.first_parm)[k][j] - (*temp_parm.second_parm)[k][j];
	}
}



/**
This method get from the user three matrices,
And double the first two matrices,Then put the result in the third.
*/
void mul_mat(void) {
	int i = get_three_matrices_names();
	if (i) {
		int h = 0;
		int k = 0;
		int j = 0;
		double sum;
		for (h = 0; h < SIZE; h++)
			for (k = 0; k < SIZE; k++) {
				sum = 0;
				for (j = 0; j < SIZE; j++)
					sum += (*temp_parm.first_parm)[h][j] * (*temp_parm.second_parm)[j][k];
				(*temp_parm.result)[h][k] = sum;
			}
	}
}



/**
This method get from the user first matrix ,after a number(scalar), and a second matrix,
And double the first one in the scalar,Then put the result in the second.
*/  
void mul_scalar(void){
	char data[80];
	fgets(data, 80, stdin);
	char* ch = strtok(data, ",");
	if ((temp_parm.first_parm = get_matrix_name(0, ch)) != NULL) {
		ch = strtok(NULL, "\0");
		if (ch == NULL) {
			printf("\"ERROR: Too litel parmeters\"\n");
			return;
		}
		char* h;
		while (*ch == '\t' || *ch == ' ')/* Skip white space before the number. */
			ch++;
		if (!isdigit(*ch)) {/*if p point to a ',' the user enter couple of comma's in a 							row and if h point to somthing else then ',' and '\0' the user enter a non digit input*/
			printf("\"ERROR: Second parameter must be a real number\"\n");
			return;
			}

		double tmp = strtod(ch, &h);/*tmp holds the number, ch is a string with just the number, h is the rest of the string */
		
		if (*h != ',' && *h != '\t' && *h != ' ') {/*if p point to a ',' the user enter couple of comma's in a 							row and if h point to somthing else then ',' and '\0' the user enter a non digit input*/
			printf("\"ERROR: Second parameter must be a real number\"\n");
			return;
		}
		while (*h == '\t' || *h == ' ')/* Skip white space after the value . */
			h++;
		if (*h == ',')
			h++;/* h points to rest of the string with out the first comma */
		printf("%s\n", h);
		if ((temp_parm.result = get_matrix_name(2, h)) != NULL) {
			int k = 0;
			int j = 0;
			for (k = 0; k < SIZE; k++)
				for (j = 0; j < SIZE; j++)
					(*temp_parm.result)[k][j] = (*temp_parm.first_parm)[k][j] * tmp;
		}
	}
}


/**
This method get from the user 2 matrices and transfer the frist one,
And put the result in the second.
*/
void trans_mat(void){
	char data[80];
	fgets(data, 80, stdin);
	char* ch = strtok(data, ",");
	if ((temp_parm.first_parm = get_matrix_name(0, ch)) != NULL) {
		ch = strtok(NULL, "\0");
		if ((temp_parm.result = get_matrix_name(1, ch)) != NULL) {
			int k = 0;
			int j = 0;
			for (k = 0; k< SIZE; k++)
				for (j = 0; j< SIZE; j++)
					(*temp_parm.result)[j][k] = (*temp_parm.first_parm)[k][j];
		}
	}
}



/**
Insert the numbers to the desirable matrix.

@param matrix the adress of the desirable matrix. 
*/
void get_data(mat *matrix) {

	mat temp = { 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0 };

	char* num[] = { "second","third","fourth","fifth","sixth","eighth","ninth","tenth","eleventh","twelfth","thirdteenth",
		"foureenth","fifeenth","sixeenth","seventeenth" };
	char *p = strtok(NULL, "\0");
	char *h;
	int i = 0;
	double tmp;

	while (p != NULL && *p != '\n' && i<16) {
		while (*p == '\t' || *p == ' ')/* Skip white space before the number. */
			p++;
		tmp = strtod(p, &h);/*tmp holds the number, p is a string with just the number, h is the rest of the string */

		while (*h == '\t' || *h == ' ')/* Skip white space after the value . */
			h++;
		if (!isdigit(*p) || *p == ',' || (*h != ',' && *h != '\0' && *h != '\n')) {/*if p point to a ',' the user enter couple of comma's in a 							row and if h point to somthing else then ',' and '\0' the user enter a non digit input*/
			printf("\n\"Worng parameters, %s parameter must be a real number\"\n", num[i]);
			return;
		}
		else {
			if (*h == ',')
				h++;/* h points to rest of the string with out the first comma */
			p = strtok(h, "\0");/* p points to the rest of the string*/
			temp[i / 4][i % 4] = tmp;
			i++;
		}
	}
	int k = 0;
	int j = 0;
	for (k = 0; k< SIZE; k++)
		for (j = 0; j< SIZE; j++)
			(*matrix)[k][j] = temp[k][j];
}


