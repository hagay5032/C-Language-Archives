#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#define SIZE 4
#define FOREVER for(;;)
#define ok 1

typedef double mat[SIZE][SIZE];

void print_mat(void);
int get_three_matrices_names(void);
void add_mat(void);
void read_mat(void);
void sub_mat(void);
void mul_mat(void);
void mul_scalar(void);
void trans_mat(void);
void stop(void);
mat *get_matrix_name(int ,char *);
void get_data(mat *matrix);



